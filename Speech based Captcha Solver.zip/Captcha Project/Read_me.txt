Submitted by - 
Anamitra Mukherjee (214101007)
Rittick Mondal (214101041)

Instructions to run the program :- 

-> Extract the zip file.

-> Open the project(.sln) in visual studio 2010.

-> Run the program, then the GUI will get displayed.

-> First go through the guidelines.

-> Then play with the application.

-> If any problem occurs, watch the demo video.
